# 四弦 KS 接入与验收记录

本轮在 `/home/ice/Project/synth-review-work-20261003` 完成四条独立 Karplus–Strong 弦与 DDS/KS 网页控制。Git HEAD 保持 `54f0a1b`，修改保留为未提交文件；Wi-Fi、USB 采集、已生成 IP 和技能改动从完整基线保留。没有烧录 FPGA 或 ESP32。

## 实现内容

- FPGA 噪声激励、两遍填环去直流、两点平均反馈、损耗与一阶全通分数调音。复用已验证的官方 `65536×16` RAM，划分 `4×16384`，不使用录音样本或 CSP 存储端口。
- 每采样帧处理四弦、宽位混音与 PCM24 饱和；与 DDS 帧对齐后进入现有 `output_tilt`、测试音选择和 PT8211 输出。DDS 的数值及延迟路径保留。
- 淡入32样本、NoteOff释放960样本、抢占淡出128样本；Off、Panic、模式切换和复位取消在途初始化，旧 RAM 内容不能重新成为有效声音。
- `0x0500–0x05FF` 原子提交与状态查询，分别报告受理和初始化完成；稳定 request/ack 跨时钟握手，忙时明确拒绝。复位还会清除旧 DDS 银行切换请求。
- ESP32 单 SPI owner，四弦按闲置、释放、最旧持有弦分配。MIDI 来源、通道和网页租约保留归属，支持力度、延音、音量、声像及目标衰减。
- 网页默认 DDS，KS 目标 T60 默认3秒、范围0.2–8秒；没有 KS01 能力时禁用 KS。模式切换清键并要求重新按键。确认丢失或 FPGA 复位会清旧 On，等待静音银行及安全 DDS 模式读回后恢复。

KS 音高在 NoteOn 确定；实时弯音、模态/FDTD 实时引擎、Schroeder 混响和延迟尚未接入。原 DDS 32 声部和弯音保留。

## 资料、定点合同与接口

论文和作者开源实现是主要参考，本地收藏用于辅助比较。没有把第三方有疑问的调音流水线直接复制到活动 RTL。完整提交号、来源、许可证观察、文件 SHA256 和混响拓扑区分见 [研究记录](physical-modeling/README.md) 与 [来源清单](physical-modeling/source-manifest.json)。

参数量化使用正负对称半离零舍入；逐样本乘积保留完整宽度和保护位后按正负对称向零截断，再在缩窄前饱和。这避免把负数算术右移当成对称缩窄，也有利于晚期尾音趋零。精确公式、独立黄金模型、初始化流程与可达衰减限制见 [定点复现说明](physical-modeling/bit-exact-ks.md)，寄存器见 [控制协议](physical-modeling/ks-control-protocol.md)。

## 已运行的验证

| 检查 | 实际结果与边界 |
| --- | --- |
| Python 独立模型 | 30项通过；全部128 MIDI在0.2/3/8秒参数下合法；E2–E6 seeded信号音准最大误差0.172 cents，基于配置推算采样率 |
| 官方 RAM 单弦黄金数据 | 三组各4096帧逐位一致，含正负极端调音系数 |
| 完全独立生命周期模型 | 2780帧 PCM、模式、active/init/release 和 started 序号一致；不读取 DUT 内部淡变计数 |
| 四弦/调度/边界 | 四弦独立、环长2/16384、RAM同步读取/环绕、重拨/抢占/取消；正常前台处理78拍，周期预算768拍 |
| 初始化/除法/超期 | 四个最大环初始化529151拍，约7.176 ms；有符号向下取整32770例；人为20次超期抑制旧帧并恢复 |
| SPI/mailbox | 最后一位提交、SCLK停止、稳定载荷、busy/非法拒绝、mask/sequence读回、双域复位及旧CTRL取消通过 |
| 固件与页面逻辑 | 11组 C/参数测试和实际页面 JS 通过；包含归属/延音/租约/模式与复位恢复 |
| ESP-IDF 6.1 | S3 Wi-Fi开、S3 Wi-Fi关、真实C3三个构建通过，交付文件与构建产物 SHA 一致 |
| 官方Gowin综合/布局布线/STA | 最终core `1b1d1214…`：建立/保持0违规，Fmax77.075 MHz（目标73.734），最差setup +0.588 ns、hold +0.169 ns；报告/源码指纹/位流封存 |
| 最终板级仿真 | DDS与完整接入前顶层103400周期逐位一致；KS512帧黄金数据/帧对齐一致；256连续CSP写入压力下deadline=0；PT8211实际串行引脚2627帧通过；释放/取消/模式通过 |

DSP 参数来自 PLL 配置推算 `Fs=96008.04324894515 Hz`，不是采样时钟实测。模型测量不能证明实物音准、音色或 Wi-Fi/BLE 同时使用的延迟。高音两点平均损耗限制可达 T60，MIDI127 尾音尤其短；不承诺全部音区音色/衰减一致。

最终布局布线资源：Logic19752/138240（15%）、FF9150/139095（7%）、BSRAM132/340（39%）、DSP53/298（18%），0 latch。通过寄存授权、缓存四弦元数据及提前寄存RAM写数据缩短组合路径；不增加FSM拍数或改变768拍/采样。前两轮虽通过但仅+0.016/+0.002 ns，第三轮出现248个setup违规；这些原始报告另存用于审核，禁止把第三轮位流当成交付。最终STA gate还检查恢复/移除裕量，不能只凭`gw_sh`退出0判断成功。

最终独立公共接口比较共19164帧：2780生命周期、12288固定单弦、4096帧初始化期间其他弦GAIN/LOSS；全绑定最终core SHA `1b1d12143d5fa0924c288e97a58bc866bae9e069718a0a873b72770971500f47`，deadline=0。核心调度回归10346逐弦算术样本/4870帧通过。原有音频、SPI、CSP、CH569控制和24项上位机测试通过；Tk停止保存测试用沙箱外Xvfb实际通过。浏览器证据来自明确标注NO HARDWARE的本地fixture，不能代表ESP32实物HTTP/SPI联调。

原有 `CK3000` 异步时钟关系提示和 `PR1014` 通用时钟路由警告仍在原始日志中；跨域功能由mailbox/复位仿真与原SDC时钟分组共同约束，实体板SPI/时钟质量仍需验收。Gowin运行自动改写的GUI process_config已按认证基线恢复；复现时以已封存 `.gprj` 和 `run_project.tcl` 的实际选项为准。

## 复现入口

```bash
bash tools/tests/physical_modeling/run.sh /tmp/ks-model-check
bash development/tang_mega_138k_synth/physical_modeling/sim/run_ks_kernel.sh
bash development/tang_mega_138k_synth/physical_modeling/sim/run_ks_golden_vectors.sh /tmp/ks-model-check/vectors
python3 tools/tests/physical_modeling/compare_ks_lifecycle.py --out /tmp/ks-lifecycle-check
python3 tools/tests/physical_modeling/compare_ks_rtl_vectors.py --out /tmp/ks-external-check
REQUIRE_KS_BASELINE=1 bash tools/tests/rtl/run_ks_integration.sh
REQUIRE_GOWIN_SIM=1 KS_RTL_EXTENDED=1 bash tools/ci/run-module-tests.sh
python3 tools/tests/rtl/check_gowin_timing.py development/tang_mega_138k_synth/audio_i2s/eda_proj/impl/pnr/project.tr
```

官方仿真模型默认取本机 Gowin V1.9.12.04 的 GW5A `prim_sim.v`；其他安装设置 `GOWIN_PRIM_SIM`。板级 DDS 对照默认读取外部完整 `00-current-tree/restore-check`，可设置 `KS_BASELINE_ROOT`；缺失时明确跳过，`REQUIRE_KS_BASELINE=1` 将其视为失败。所有 `vvp` 使用 `-N`、返回码、失败扫描和真实 PASS 标记，`$stop` 不能充当通过。

正式活动清单以 `.gprj` 为准。官方构建使用 `audio_i2s/eda_proj/scripts/run_project.tcl all`；不改约束来规避时序检查。固件、位流、源码指纹和验证日志放在 [配套交付](../releases/ks-physical-model-20261003/README.md)。

## 快照与实体板验收

完整基线和各功能快照保存于工作树外，带 Git历史、状态/差异、文件权限/哈希及恢复验证；[中文快照索引](snapshots/ks-physical-model-20261003/README.md)说明每份范围。最终整合源码在当前工作树，分支未合回原 `main`。

上板后还需验收：SPI启动自检、KS能力读回、四音满力度混音、E2–E6音准、低/高极端音区、10ms释放尾音、模式清键、初始化中Panic/复位、网页断连，以及 Wi-Fi/BLE 共存情况下控制到 PT8211 首个有效 PCM 的延迟。固件持续恢复状态意味着硬件故障尚未消除，不能声称实物已静音。
