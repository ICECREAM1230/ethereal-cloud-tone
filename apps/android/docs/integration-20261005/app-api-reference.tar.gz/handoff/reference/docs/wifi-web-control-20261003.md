# ESP32-S3 本地 Wi-Fi 网页控制（2026-10-03）

## 交付与连接

在独立工作树 `synth-wifi-web-control-20261003`，基于 `54f0a1b` 实现手机本地
控制，未提交、未烧录、未更改 `.ai/`。现有 BLE MIDI、DIN MIDI、FPGA SPI 与
减法合成逻辑保留；未开发 USB MIDI、音色存储或物理建模。

- 热点 **FPGA_Project**，演示 WPA2 密码 **Fpga-Synth-2026**。
- 手机保持热点连接，打开 `http://192.168.4.1`。全部资源内嵌，无 CDN。
- 蓝牙 **FPGA_Bluetooth**；主广播 flags + MIDI 128-bit UUID 共 21 bytes，
  完整名称在 scan response 中占 16 bytes，均不超过 legacy 31-byte 上限。
  GAP 名称与 scan response 使用同一个常量，错误返回被检查，重新广播复用同一路径。
- 配套可审核固件：[releases/wifi-web-control-20261003](../releases/wifi-web-control-20261003/README.md)。
  应用 1,149,616 bytes，官方单应用大分区 1500 KiB，剩余 386,384 bytes（25%）。
  原 1 MiB 分区不足，后续部署须使用新的配套分区表。
- [源快照索引](snapshots/wifi-web-control-20261003/README.md)；源码 SHA256 与独立构建日志随交付保存。

## 控制边界与线程所有权

HTTP server 独占自己的 session 表与所有 HTTP API 调用，任务 priority 3，低于
声部 priority 5。Wi-Fi startup 失败会释放 AP/server 资源，不让可选网页故障
重启现有音乐任务。最多四个页面，SSID、WPA2 密码、信道和功能开关由 Kconfig
配置。固定密码可更换；空密码配置首次生成随机密码并保存 NVS，重启不更换。
S3 defaults 打开 Wi-Fi 与软共存，C3 defaults 关闭网页；关闭配置后不嵌入页面且
`wifi_web_start()` 为 stub。CMake 在早期依赖发现时仍声明网络组件，避免 IDF
第一次扫描时缺头文件；关闭版本不会启动网络驱动。

HTTP 不修改 `g_patch`，不调用 FPGA 直接 SPI API。所有参数、键盘与紧急停止
均以固定大小的 `EVT_WEB` 发布到现有可靠事件总线。`voice_alloc` 仍是唯一
音色/声部 owner，`engine_link` 仍是运行期 SPI owner。HTTP 从带临界区保护的
原始 RAM 快照读取，JSON 格式化和 CC 逆映射在 HTTP/浏览器侧，避免在音乐
deadline 中做格式化。快照只在事件、按键推进、租约释放或参数推进状态变化
时更新，不在每个空 1 ms tick 复制。状态 ready 由已运行的声部任务发布。

网页初次加载只读当前 patch；默认 `7+1`、主 saw + 低八度 sine、volume `207`
以及真实 ADSR 不被 CC 近似值覆盖。波形映射、三种声部结构和滤波类型沿用
现有 CC 区间。原始状态包含 patch 以及 cutoff/resonance 运行时偏移；原始值
和近似控件值均属于 ESP32 控制侧，**不代表 FPGA 读回或实际声音**。
参数返回分“HTTP 已接收”和“ESP32 已处理”，后者有独立 parameter sequence，
不被后续键盘心跳覆盖。参数生成中的 pending 标志也不冒充硬件完成。

键盘覆盖 MIDI 48–72（C3–C5），用完整 bitmap 和 250 ms 心跳；ESP32 租约
1.2 秒，session 槽 10 秒无请求可复用。网页按 token 记录每个 voice 的 owner，
两个页面或 BLE 同音高松键不会释放另一个网页的 voice。25 键和弦按 owner
剩余 batch budget 公平推进，一步不超过一次普通 MIDI note transaction。
失焦、隐藏和 pagehide 尝试发送零 bitmap，无法发送时由租约释放；超时后
必须先看到零 bitmap 才允许重新持键，旧请求不复活音符。过期检查也先于
新心跳续约，防止 owner 恢复运行时被迟到心跳掩盖超时。

页面用最多 32 个 bitmap 转换 frame 保留短按 On/Off；HTTP 忙时不把短按
合并成零状态。HTTP 202 后等待 `state.keys` 与处理序号体现 voice owner 已
采用该 frame，再发下一帧，避免 On/Off 在同一 owner 批次被覆盖；这仍不是
FPGA GateOn ack。超过 300 ms 的旧 On 清队列并松键，不晚到重放。多触点同键
以 pointer map 计数。手机键盘允许内部横向 pan，手势取消会松键，页面自身
没有横向溢出。Release 尾音可以继续；紧急停止和可靠总线 overflow/source-loss
的 `EVT_PANIC` 都先清 bus 1023 测试音 latch，再停止所有来源 voice。

另修复初始 CC74 coarse 从 `0` 到 `64`：真实默认 cutoff offset 为零，第一次
仅动 CC106 fine 不应突然跳到 -8 八度。该边界有 host 回归。

## 本地 API

GET `/` 为内嵌中文页面，GET `/api/state` 返回原始 ESP32 快照。
POST `/api/session`（空 body）分配 token/client。POST `/api/command` 的 body
为严格 ASCII 十进制 `token sequence op a b`；长度小于 96 bytes，无尾部垃圾、
负号、溢出或 NUL。必须带 `X-FPGA-Control: 1`，没有 CORS，因此跨源页面
无法通过自定义 header 的预检随意发送控制。AP 密码是本地接入控制边界。

| op | a | b | 含义 |
| --- | --- | --- | --- |
| 2 | 已实现 CC 白名单 | 0–127 | 改单个参数；禁止 CC119、120 等通用逃逸入口 |
| 3 | 25-bit bitmap，0–33554431 | 1–127 | 网页键盘目标与力度、续约 |
| 4 | 0 | 0 | 清测试音并全来源紧急停止 |

HTTP 202 只表示已发布，状态 `parameter_processed` / `stop_processed` 表示
voice owner 已采用请求；所有响应的 `fpga` 为 `unverified`。旧 sequence 返回
409、过期/未知 session 返回 410、四槽占满返回 503、无效 body 返回 400。
键盘调用方需按页面的 owner adoption fence 推進 frame，不能把 202 当作已发声。

## 验证

| 验证 | 结果与边界 |
| --- | --- |
| `bash tools/tests/firmware/run.sh` | 七组 PASS：事件、engine 事务、deadline、公平推进、RC release、SPI fences、MIDI source、网页控制（网页为新增第七组） |
| 新 `test_web_control.c` | PASS：严格范围、真实 defaults、同音高 owner 隔离、seq/token、lease 禁止复活、迟到续约、panic 清测试音、overflow 保守静音、25 键 cost model 分批 |
| `node tools/tests/firmware/test_web_page.js` | PASS：实际页面 script 无默认写、HTTP busy 短按、同键双 pointer、owner adoption fence、旧 On 释放、力度取整 |
| 主代理独立解析器 oracle | 5010 个合法/非法报文案例一致，包含 uint32、尾部垃圾、CC119/120、bitmap、零值边界 |
| 主代理真实浏览器 fixture | 波形/参数 ACK/停止 ACK 正常；390 viewport 下 document client/scrollWidth 均 375，键盘内部横滚；不是板上浏览器链路验收 |
| ESP-IDF v6.1 S3 Wi-Fi on | PASS，最终 0x118ab0 app、factory 0x177000，最终日志无编译 warning/error |
| ESP-IDF v6.1 S3 Wi-Fi off | PASS，app 0x89010，未启用 Wi-Fi 功能 |
| ESP-IDF v6.1 ESP32-C3 | PASS，显式 `IDF_TARGET=esp32c3`、Wi-Fi 默认关闭，app 0x975e0，原 1 MiB 分区可容纳 |
| `git diff --check`、交付 SHA256 | PASS；未提交、未暂存，只有本轮 task-scoped 文件更改 |

Host stub 的临界区是空宏，以上回归不证明 FreeRTOS 并发或射频实时性能。
没有实板烧录、SPI 联通、手机真实多触摸、BLE/Wi-Fi 共存、音频或延迟验收；
这些需要配套 FPGA 位流和硬件执行。不存在物理建模或 USB MIDI 的可用性宣称。

构建目录与 sdkconfig 全部在 `/tmp/`：

```bash
. /home/ice/esp/esp-idf-v6.1/export.sh
# 在 development/tang_mega_138k_synth/esp32s3 目录
idf.py -B /tmp/synth-wifi-web-s3-build -D SDKCONFIG=/tmp/synth-wifi-web-s3-sdkconfig build
# Wi-Fi off defaults 是 S3 sdkconfig.defaults 将开关替换为 n 后的临时文件
idf.py -B /tmp/synth-wifi-off-s3-build -D SDKCONFIG=/tmp/synth-wifi-off-s3-sdkconfig -D SDKCONFIG_DEFAULTS=/tmp/synth-wifi-off.defaults build
# 在 development/tang_mega_138k_synth/esp32c3 目录
idf.py -B /tmp/synth-wifi-compat-real-c3-build -D IDF_TARGET=esp32c3 -D SDKCONFIG=/tmp/synth-wifi-compat-real-c3-sdkconfig build
```

如沿用旧本地 sdkconfig，需在 menuconfig 打开 Wi-Fi、改 SSID，并选 S3 大单应用
分区；`sdkconfig.defaults` 不会强制覆写已有用户配置。

离线浏览器 fixture：`python3 tools/tests/firmware/web_preview.py --port 8765`，
仅绑定 `127.0.0.1`，无 ESP32/FPGA，模拟有限的 volume/wave 和处理状态，10 秒
空闲 session 可复用；不提供实际 synth/lease 音频证明。

接口依据：Context7 查询到官方 ESP-IDF release-v6.0 网络 API，并结合本机 v6.1
官方 `examples/wifi/getting_started/softAP` 与头文件编译核验；本版采用 HTTP
而非 WebSocket。参考 [ESP-NETIF](https://docs.espressif.com/projects/esp-idf/en/release-v6.0/esp32c6/api-reference/network/esp_netif.html)、
[Wi-Fi API](https://docs.espressif.com/projects/esp-idf/en/release-v6.0/esp32c6/api-reference/network/esp_wifi.html)、
[S3 HTTP server](https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/api-reference/protocols/esp_http_server.html)。
