// ble_midi.h — MIDI over Bluetooth LE (peripheral, standard MIDI service)
//
// Copyright © 2026 Thor H. Linløkken <thj@thj.no>
// License: MIT

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// Bring up the NimBLE peripheral hosting the standard MIDI 1.0 over
// BLE service, advertising as "Ethereal Cloud Tone". Incoming MIDI is published to
// the event bus exactly like wired MIDI (midi_in). Call once at boot,
// after event_bus_init.
void ble_midi_init(void);

// Serial console key 'p': log stack state and re-trigger advertising
// (safe from any task). Part of the shared console dispatcher.
void ble_midi_console_status(void);

#ifdef __cplusplus
}
#endif
