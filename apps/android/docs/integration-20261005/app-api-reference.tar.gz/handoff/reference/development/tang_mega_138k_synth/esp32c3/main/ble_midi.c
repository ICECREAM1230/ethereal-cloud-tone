// ble_midi.c — MIDI over Bluetooth LE (peripheral)
//
// Copyright © 2026 Thor H. Linløkken <thj@thj.no>
// License: MIT
//
// Implements MIDI 1.0 over BLE (the MMA / Bluetooth SIG service):
// primary service 03B80E5A-EDE8-4B33-A751-6CE34EC4C700 carrying one
// "MIDI data I/O" characteristic 7772E5DB-3868-4112-A1A9-F2669D106BF3
// (read, write, write-without-response, notify). Centrals with BLE
// MIDI support — macOS Audio MIDI Setup, Android 13+, iOS — discover
// "FPGA_Bluetooth" and treat it like any wired MIDI port.
//
// Packet format: two header bytes holding a 13-bit millisecond
// timestamp; bit 7 of the second header byte set means a status byte
// follows (running status restarts), clear means the payload
// continues under running status. Timestamps are consumed and
// discarded — this synth has no event scheduling, everything sounds
// on arrival. The payload bytes run through the shared midi_parser,
// which already understands running status and the Note-On-vel-0
// convention.
//
// Threading (#83): the GATT access callback (NimBLE host task) only
// COPIES the packet into a ring buffer; a lower-priority ble_rx task
// drains it, strips the BLE-MIDI framing, feeds the shared parser and
// publishes to the event bus. Parsing in the host task starved IDLE
// under a sustained ~1 kHz BLE flood (task watchdog with btController
// running — found by tools/ble_midi_fuzz.py). Overflow drops packets
// at the ring buffer, counted and forcing panic because a missing packet
// may contain NoteOff. Source epochs invalidate queued/in-flight packets on
// loss/reconnect; ble_rx alone resets running status at generation changes.

#include "ble_midi.h"

#include <string.h>

#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/ringbuf.h"
#include "freertos/task.h"
#include "host/ble_hs.h"
#include "host/ble_store.h"
#include "host/util/util.h"
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"

// NimBLE's NVS-backed bond store (no public header for this in IDF;
// the bundled bleprph example declares it the same way)
void ble_store_config_init(void);

#include "event_bus.h"
#include "midi_parser.h"
#include "midi_source.h"

#define TAG "ble_midi"

// Standard MIDI 1.0 over BLE service (03B80E5A-EDE8-4B33-A751-6CE34EC4C700)
// and its MIDI data I/O characteristic (7772E5DB-3868-4112-A1A9-F2669D106BF3).
// BLE_UUID128_INIT takes the bytes in on-air (little-endian) order, i.e.
// the printed UUID reversed.
#define MIDI_SVC_UUID BLE_UUID128_INIT(0x00, 0xC7, 0xC4, 0x4E, 0xE3, 0x6C, 0x51, 0xA7, \
                                       0x33, 0x4B, 0xE8, 0xED, 0x5A, 0x0E, 0xB8, 0x03)
#define MIDI_IO_UUID BLE_UUID128_INIT(0xF3, 0x6B, 0x10, 0x9D, 0x66, 0xF2, 0xA9, 0xA1, \
                                      0x12, 0x41, 0x68, 0x38, 0xDB, 0xE5, 0x72, 0x77)

// Largest possible packet: the negotiated ATT MTU (we prefer 517).
#define BLE_MIDI_MAX_PKT 517

static const ble_uuid128_t gatt_svr_svc_midi_uuid = MIDI_SVC_UUID;
static const ble_uuid128_t gatt_svr_chr_midi_io_uuid = MIDI_IO_UUID;
static uint16_t gatt_svr_chr_midi_io_handle;

// Advertising is one-shot: the stack stops it when a connection
// forms, and the GAP callback restarts it on failure/disconnect.
static bool s_advertising;
static int s_conn_count;

static midi_parser_t g_ble_parser;
static midi_source_t s_source={.id=MIDI_SOURCE_BLE};
static uint32_t s_parser_epoch;

// Ingress ring buffer (#83): NOSPLIT keeps packet boundaries, which
// the BLE-MIDI framing needs. 4 KB ≈ 8 max-MTU packets or hundreds of
// typical 5-byte ones.
#define BLE_RX_RB_SIZE   4096
#define BLE_RX_TASK_STACK 3072
#define BLE_RX_TASK_PRIO  4
static RingbufHandle_t s_rx_rb;
static uint32_t s_rx_drops;

// Parser callback runs only in ble_rx. A source epoch check prevents queued
// or in-flight bytes from reviving notes after disconnect/ingress overflow.
static void ble_msg_to_bus(const midi_message_t *m, void *user)
{
    (void)user;
    midi_source_publish(&s_source,s_parser_epoch,m);
}

// ── Packet processing (ble_rx task context, #83) ───────────────────
// Header: 13-bit timestamp in two bytes. Bit 7 of the second byte
// set = timestamp present and a status byte follows; clear =
// running status continues.
static void process_ble_midi_pkt(const uint8_t *pkt, uint16_t n)
{
    int idx = 2;
    if (pkt[1] & 0x80) {
        if (idx >= n) {
            return;   // status promised, absent — drop the runt
        }
        midi_parser_feed(&g_ble_parser, pkt[idx++]);
    }
    while (idx < n) {
        midi_parser_feed(&g_ble_parser, pkt[idx++]);
    }
}

// Drain the ingress ring buffer, with the standard single-core yield
// guard (#70/#83): after ~2 ms of unbroken work, give IDLE a tick.
static void ble_rx_task(void *arg)
{
    int64_t busy_since = esp_timer_get_time();
    while (1) {
        size_t n = 0;
        uint8_t *pkt = xRingbufferReceive(s_rx_rb, &n, pdMS_TO_TICKS(100));
        if (pkt == NULL) {
            busy_since = esp_timer_get_time();   // we blocked
            continue;
        }
        if (n >= sizeof(uint32_t)+2) {
            uint32_t epoch;
            memcpy(&epoch,pkt,sizeof(epoch));
            if (midi_source_current(&s_source,epoch)) {
                if (s_parser_epoch!=epoch) {
                    midi_parser_reset(&g_ble_parser);
                    s_parser_epoch=epoch;
                }
                process_ble_midi_pkt(pkt+sizeof(epoch),(uint16_t)(n-sizeof(epoch)));
            }
        }
        vRingbufferReturnItem(s_rx_rb, pkt);

        if (s_rx_drops) {
            ESP_LOGW(TAG, "rx ring full, dropped %" PRIu32 " packets",
                     s_rx_drops);
            s_rx_drops = 0;
        }
        int64_t now = esp_timer_get_time();
        if (now - busy_since > 2000) {
            vTaskDelay(1);
            busy_since = esp_timer_get_time();
        }
    }
}

// ── GATT access callback ───────────────────────────────────────────
// Writes carry one BLE MIDI packet (possibly several MIDI messages
// under running status). COPY into the ring buffer and return — never
// parse in the NimBLE host task (#83).
static int gatt_svr_chr_access(uint16_t conn_handle, uint16_t attr_handle,
                               struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    if (ctxt->op != BLE_GATT_ACCESS_OP_WRITE_CHR) {
        return 0; // reads (and CCCD bookkeeping) pass through
    }

    struct os_mbuf *om = ctxt->om;
    uint16_t n = OS_MBUF_PKTLEN(om);
    if (n < 2) {
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN; // no header at all
    }

    struct {uint32_t epoch; uint8_t bytes[BLE_MIDI_MAX_PKT];} packet;
    if (n > sizeof(packet.bytes)) {
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN; // beyond negotiated MTU
    }
    packet.epoch=midi_source_snapshot(&s_source);
    if (!packet.epoch) return 0;
    os_mbuf_copydata(om, 0, n, packet.bytes);

    if (xRingbufferSend(s_rx_rb, &packet, sizeof(packet.epoch)+n, 0) != pdTRUE) {
        s_rx_drops++;
        midi_source_overflow(&s_source); // an upstream lost Off also needs panic
    }
    return 0;
}

// Issue #67 notes:
// - NO manual CCCD descriptor: NimBLE auto-creates the CCCD for any
//   NOTIFY characteristic. The hand-declared one here produced TWO
//   CCCDs on the characteristic — a GATT violation some centrals
//   punish with a disconnect.
// - Encryption is SUPPORTED, not REQUIRED (issue #79). The SM config
//   in ble_midi_init() lets Apple pair+encrypt by its own BLE-MIDI
//   policy — that (not a characteristic flag) is what fixed the
//   macOS reason-531 drops. Adding _ENC flags to REQUIRE encryption
//   then broke Android, which connects without pairing (BLE MIDI
//   Engineer Lite: connects but writes rejected, no MIDI). Plain
//   READ/WRITE serves both: Apple still encrypts, Android works.
static const struct ble_gatt_chr_def gatt_svr_chrs[] = {
    {
        .uuid = &gatt_svr_chr_midi_io_uuid.u,
        .access_cb = gatt_svr_chr_access,
        .flags = BLE_GATT_CHR_F_READ |
                 BLE_GATT_CHR_F_WRITE |
                 BLE_GATT_CHR_F_WRITE_NO_RSP |
                 BLE_GATT_CHR_F_NOTIFY,
        .val_handle = &gatt_svr_chr_midi_io_handle,
    },
    { 0, }
};

static const struct ble_gatt_svc_def gatt_svr_svcs[] = {
    {
        .type = BLE_GATT_SVC_TYPE_PRIMARY,
        .uuid = &gatt_svr_svc_midi_uuid.u,
        .characteristics = gatt_svr_chrs,
    },
    { 0, }
};

// ── Advertising ────────────────────────────────────────────────────

static int ble_midi_gap_event(struct ble_gap_event *event, void *arg);

// Log the parameters actually in effect on a connection — the
// supervision timeout is what a reason-520 (0x08) drop hinges on
// (issue #67). Units per HCI: interval 1.25 ms, timeout 10 ms.
static void log_conn_params(uint16_t conn_handle)
{
    struct ble_gap_conn_desc d;
    if (ble_gap_conn_find(conn_handle, &d) != 0)
        return;
    ESP_LOGI(TAG, "conn params in effect: itvl=%u (%u.%02u ms) latency=%u "
                  "timeout=%u (%u ms)",
             d.conn_itvl, (d.conn_itvl * 125) / 100, (d.conn_itvl * 125) % 100,
             d.conn_latency, d.supervision_timeout, d.supervision_timeout * 10);
}

// Request our preferred connection parameters. Apple-friendly:
// 15-30 ms interval, no latency, 6 s supervision (generous, so a
// brief RF hiccup can't trip a reason-520 timeout). MUST run AFTER
// encryption — requesting it in the CONNECT event collided with
// macOS's own pairing procedure (observed status=554 = HCI 0x2A,
// different transaction collision) and was rejected (issue #67).
static void request_conn_params(uint16_t conn_handle)
{
    struct ble_gap_upd_params up = {
        .itvl_min = 12, .itvl_max = 24,
        .latency = 0, .supervision_timeout = 600,
    };
    ble_gap_update_params(conn_handle, &up);
}

static const char s_ble_name[] = "FPGA_Bluetooth";
_Static_assert(sizeof(s_ble_name) + 1 <= 31, "BLE name exceeds scan response");

static void ble_midi_advertise(void)
{
    struct ble_gap_adv_params adv_params;
    struct ble_hs_adv_fields fields;
    int rc;

    memset(&fields, 0, sizeof fields);
    fields.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    fields.uuids128 = (ble_uuid128_t *)&gatt_svr_svc_midi_uuid;
    fields.num_uuids128 = 1;
    fields.uuids128_is_complete = 1;

    rc = ble_gap_adv_set_fields(&fields);
    if (rc != 0) {
        ESP_LOGE(TAG, "adv fields: rc=%d", rc);
        return;
    }

    // Legacy ADV: flags (3) + MIDI UUID (18) = 21 bytes. Full name
    // belongs in scan response: 2 + 14 = 16 bytes (ADV limit is 31).
    memset(&fields, 0, sizeof fields);
    fields.name = (uint8_t *)s_ble_name;
    fields.name_len = sizeof(s_ble_name) - 1;
    fields.name_is_complete = 1;
    rc = ble_gap_adv_rsp_set_fields(&fields);
    if (rc != 0) {
        ESP_LOGE(TAG, "scan response fields: rc=%d", rc);
        return;
    }

    memset(&adv_params, 0, sizeof adv_params);
    adv_params.conn_mode = BLE_GAP_CONN_MODE_UND;
    adv_params.disc_mode = BLE_GAP_DISC_MODE_GEN;
    rc = ble_gap_adv_start(BLE_OWN_ADDR_PUBLIC, NULL, BLE_HS_FOREVER,
                           &adv_params, ble_midi_gap_event, NULL);
    if (rc != 0) {
        ESP_LOGE(TAG, "adv start: rc=%d", rc);
        return;
    }
    s_advertising = true;
}

static int ble_midi_gap_event(struct ble_gap_event *event, void *arg)
{
    switch (event->type) {
    case BLE_GAP_EVENT_CONNECT:
        s_advertising = false;
        if (event->connect.status != 0) {
            ESP_LOGW(TAG, "connect failed, re-advertising");
            ble_midi_advertise();
        } else {
            midi_source_open(&s_source);
            s_conn_count++;
            ESP_LOGI(TAG, "MIDI connection established");
            log_conn_params(event->connect.conn_handle);
            // params requested AFTER encryption (see ENC_CHANGE) to
            // avoid the pairing-time collision (issue #67)
        }
        return 0;

    case BLE_GAP_EVENT_DISCONNECT: {
        // Source ownership is omni today. Conservatively silence all voices
        // on source loss; the reliable subscriber latches this even under flood.
        midi_source_close(&s_source);
        if (s_conn_count > 0) {
            s_conn_count--;
        }
        // reason = 512 + HCI code; 531 = 0x13 remote user terminated
        ESP_LOGI(TAG, "disconnected (reason=%d / HCI 0x%02x), advertising",
                 event->disconnect.reason, event->disconnect.reason - 512);
        ble_midi_advertise();
        return 0;
    }

    // A central re-pairing while it holds a stale bond (our side lost
    // or rotated keys): NimBLE's default REJECTS it, which the
    // central answers by disconnecting (issue #67). Delete our stale
    // peer entry and let the pairing retry.
    case BLE_GAP_EVENT_REPEAT_PAIRING: {
        struct ble_gap_conn_desc desc;
        if (ble_gap_conn_find(event->repeat_pairing.conn_handle, &desc) == 0) {
            ble_store_util_delete_peer(&desc.peer_id_addr);
        }
        ESP_LOGI(TAG, "stale bond replaced, retrying pairing");
        return BLE_GAP_REPEAT_PAIRING_RETRY;
    }

    case BLE_GAP_EVENT_ENC_CHANGE:
        ESP_LOGI(TAG, "encryption %s (status=%d)",
                 event->enc_change.status == 0 ? "established" : "FAILED",
                 event->enc_change.status);
        if (event->enc_change.status == 0)
            request_conn_params(event->enc_change.conn_handle);  // now valid
        return 0;

    case BLE_GAP_EVENT_CONN_UPDATE:
        ESP_LOGI(TAG, "conn params updated (status=%d)",
                 event->conn_update.status);
        log_conn_params(event->conn_update.conn_handle);
        return 0;

    case BLE_GAP_EVENT_MTU:
        ESP_LOGI(TAG, "MTU %u", event->mtu.value);
        return 0;

    default:
        return 0;
    }
}

// ── Host lifecycle ─────────────────────────────────────────────────

static void ble_midi_on_sync(void)
{
    int rc = ble_hs_util_ensure_addr(0);
    if (rc != 0) {
        ESP_LOGW(TAG, "public address unavailable (rc=%d), falling back to random", rc);
        rc = ble_hs_util_ensure_addr(1);
        if (rc != 0) {
            ESP_LOGE(TAG, "no usable address (rc=%d) - not advertising", rc);
            return;
        }
    }
    ble_midi_advertise();
}

static void ble_midi_host_task(void *param)
{
    nimble_port_run(); // blocks for the life of the stack
    nimble_port_freertos_deinit();
}

// Console key 'p': print stack state and re-trigger advertising.
// NimBLE APIs are safe to call from any task (they queue to the host
// task), so this can run in the shared serial-console dispatcher.
void ble_midi_console_status(void)
{
    bool synced = ble_hs_is_enabled();
    ESP_LOGI(TAG, "BLE: host %s, advertising=%s, connections=%d",
             synced ? "synced" : "NOT synced",
             s_advertising ? "yes" : "no",
             s_conn_count);
    if (synced && !s_advertising) {
        ble_midi_advertise();
    }
}

void ble_midi_init(void)
{
    midi_parser_init(&g_ble_parser, ble_msg_to_bus, NULL);

    // Ingress decoupling (#83): ring buffer + drain task, so the
    // NimBLE never parses; source-loss panic is the only host publication.
    s_rx_rb = xRingbufferCreate(BLE_RX_RB_SIZE, RINGBUF_TYPE_NOSPLIT);
    if (s_rx_rb == NULL) {
        ESP_LOGE(TAG, "failed to create rx ring buffer");
        return;
    }
    if (xTaskCreate(ble_rx_task, "ble_rx", BLE_RX_TASK_STACK, NULL,
                    BLE_RX_TASK_PRIO, NULL) != pdPASS) {
        ESP_LOGE(TAG, "failed to create ble_rx task");
        return;
    }

    // nimble_port_init() is the full bring-up: controller enable, HCI,
    // and the NPL primitives (mutex, event queue) the host lock needs.
    // It MUST run before any service registration - ble_gatts_add_svcs
    // takes ble_hs_lock, and without this call the lock's mutex does
    // not exist yet (load access fault in xQueueSemaphoreTake, seen on
    // silicon). The bundled bleprph example calls it in app_main for
    // exactly this reason; nimble_port_freertos_init() below only
    // spawns the host task.
    ESP_ERROR_CHECK(nimble_port_init());

    // Order matters: the GAP/GATT services must exist before their
    // settings are touched (the bundled bleprph example does exactly
    // this sequence).
    ble_svc_gap_init();
    ble_svc_gatt_init();

    ble_gatts_count_cfg(gatt_svr_svcs);
    ble_gatts_add_svcs(gatt_svr_svcs);

    ESP_ERROR_CHECK(ble_svc_gap_device_name_set(s_ble_name));

    ble_hs_cfg.reset_cb = NULL;
    ble_hs_cfg.sync_cb = ble_midi_on_sync;

    // Security manager (issue #67): Apple BLE-MIDI requires an
    // encrypted link. Just-Works pairing (no IO), bonded, LE Secure
    // Connections, encryption + identity keys both ways; bonds
    // persist in NVS (CONFIG_BT_NIMBLE_NVS_PERSIST=y +
    // ble_store_config_init below) so reconnects after a reboot can
    // re-establish encryption instead of being dropped.
    ble_hs_cfg.sm_io_cap = BLE_SM_IO_CAP_NO_IO;
    ble_hs_cfg.sm_bonding = 1;
    ble_hs_cfg.sm_mitm = 0;
    ble_hs_cfg.sm_sc = 1;
    ble_hs_cfg.sm_our_key_dist =
        BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
    ble_hs_cfg.sm_their_key_dist =
        BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;

    ble_store_config_init();

    // nimble_port_freertos_init() in this IDF version wraps
    // esp_nimble_enable(): controller + host bring-up inside, void
    // return - errors surface as abort/log from the stack.
    nimble_port_freertos_init(ble_midi_host_task);

    ESP_LOGI(TAG, "BLE MIDI peripheral up, advertising as %s", s_ble_name);
}
