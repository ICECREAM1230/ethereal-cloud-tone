# Tang Mega 138K synthesizer controller (YD-ESP32-S3)

This ESP-IDF project shares the controller source in `../esp32c3/main/`.
The default build target is `esp32s3`; ESP-IDF v6.1 is the default for future
firmware work. The build does not program the ESP32 or FPGA.

The supplied YD-ESP32-S3 V1.4 board reference covers N8R2, N8R8, and
N16R8 modules. This configuration uses the common first 8 MB of Flash and
does not use PSRAM. Check the module marking before enabling PSRAM or
selecting a larger Flash layout.

| ESP32-S3 GPIO | Function | NEO Dock 31005 SDRAM0 (J13) | SOM/Dock DF40 J1 | FPGA package pin |
| --- | --- | --- | --- | --- |
| 47 | SPI SCLK | J13 pin 7, SDRAM0_D6 | pin 47 | A14 |
| 48 | SPI MISO | J13 pin 5, SDRAM0_D4 | pin 53 | B13 |
| 45 | SPI MOSI | J13 pin 3, SDRAM0_D2 | pin 59 | C15 |
| 21 | SPI CS, active low | J13 pin 9, SDRAM0_D15 | pin 41 | B16 |
| 16 | DIN MIDI UART1 RX | external MIDI input circuit | — | — |
| 2 | panel MIDI UART0 RX | external panel input circuit | — | — |
| 1 | slider ADC1 channel 0 | slider wiper | — | — |

Connect ESP32-S3 GND to J13 pin 12. Power each board from its own USB;
leave J13 pin 11 (5V_Peripheral) unconnected. The FPGA Bank 2 and S3 GPIO
use 3.3 V logic; these four differential-capable FPGA pins are configured
as single-ended LVCMOS33 GPIO. Use J13 only when no SDRAM module is attached.
The DF40 J1 numbers trace the signals between the SOM and Dock; make the
external connections at the 2.54 mm J13 header, not at the fine-pitch DF40.
Confirm the physical J13 pin-1 mark and GND with a meter before connecting;
do not infer header orientation from a schematic symbol. Keep the SPI wires
short and connect or disconnect them only with both boards powered off.

The supplied ESP32 numbers are GPIO numbers, not header positions. The
remaining connected pairs GPIO19-E19, GPIO20-C18, and GPIO0-E14 are not used
by SPI. The FPGA top reserves these three pads as passive input ports,
with `PULL_MODE=NONE`; verify `in / Drive OFF / Pull NONE` in the final PnR
report using `tools/tests/rtl/check_esp32_pin_safety.py`. GPIO19/20 retain
native USB, and GPIO0 retains the BOOT key. Firmware does not reconfigure
these three ESP32 pins. Extra PCB traces and FPGA input capacitance can
still affect USB; these settings do not establish signal integrity or the
FPGA's electrical state before configuration or with either board unpowered.
GPIO45 is a strapping pin that can select the Flash supply voltage at reset;
it is used as the ESP32 MOSI output, with the FPGA side configured as an input
without a pull-up, preserving the ESP32's default weak pull-down at reset.
See the [ESP32-S3 datasheet](https://documentation.espressif.com/esp32-s3_datasheet_en.pdf)
for strapping behavior. GPIO48 also feeds the board's RGB LED input. Do not
enable an RGB LED driver on this shared MISO pin; SPI traffic may change the
LED's color. After SPI bus initialization, S3 firmware explicitly disables
GPIO48 output, keeps the SPI input enabled, and disables both internal pulls.
The seven-wire configuration dump must show GPIO48 `InputEn: 1`,
`OutputEn: 0`, `Pullup: 0`, and `Pulldown: 0`; the SPIQ output matrix ID can
remain present with pad output disabled. SPI remains mode 0 at 10 MHz.
The startup self-test must report
`RESULT: ALL OK` before treating this wiring as verified on hardware.

The JoyCon A connector J19 is a 1.8 V FPC interface behind the Dock's
TXS0108E level translator, and J19 pin 4 carries 5 V. Do not connect
ESP32-S3 GPIO directly to J19. Older SRAM bitstreams mapped SPI to J19,
PMOD1 J8, or J13 pins 2/4/6/8; load a bitstream built from the current J13
constraints before testing SPI.

GPIO0 is the board's BOOT key and is not used for DIN MIDI. Use the native
ESP32-S3 USB/JTAG connector for logs and slider calibration keys; the CH343
USB-to-UART connector is wired to
UART0 GPIO43/44. Connect the ESP32 and FPGA grounds, and use 3.3 V I/O.
Wire MIDI inputs through their proper input circuits before testing.
The native USB connection currently carries logs and calibration keys;
USB MIDI input is not implemented. On startup, the controller mutes the
FPGA boot chord, so sound resumes when a MIDI note is received.

On this Linux host, activate ESP-IDF v6.1 with
`. "$HOME/esp/esp-idf-v6.1/export.sh"`, then run `make fw` at the repository
root. You can also run `idf.py build` here from that shell. `make fw` checks the
ESP-IDF version; these commands only build a firmware image. Flashing the S3
requires a separate hardware step and explicit authorization. The FPGA
should be loaded into SRAM first; reset the S3 after FPGA configuration
so the controller sends its parameter image to the FPGA.

The source started from Ethereal Cloud Tone `open_resource` commit `4940a08`; this
S3 project changes board pin selection and the GPIO1 ADC channel while
retaining the FPGA word protocol and control logic.

## 手机本地 Wi-Fi 控制

S3 默认启用本地热点，SSID 为 **FPGA_Project**，演示 WPA2 密码为
**Fpga-Synth-2026**。手机连接热点后，在浏览器打开
[http://192.168.4.1](http://192.168.4.1)；如手机提示无互联网，选择保持连接。
页面资源全部由 ESP32 提供，无 CDN、外部 Wi-Fi 凭据或互联网需求。
BLE MIDI 同时保留，完整设备名为 **FPGA_Bluetooth**；标准 MIDI service UUID
不变。名称放在 BLE scan response，主广播保留 MIDI UUID。

页面提供双振荡器波形、声部结构、混合、音量、声像、滤波、ADSR、失谐及
立体声宽度、LFO 1 和 C3–C5 多指键盘。第一次加载只读取真实 RAM 音色，
不会把滑块的近似 CC 数值写回默认音色。“已接收”表示 HTTP 命令已进入事件
总线；“ESP32 已处理”表示声部任务已经采用该请求。状态及原始值属于 ESP32
控制侧。配套 KS01 位流提供 DDS / 四弦 KS 模式切换及 FPGA SPI 状态读回，
包括 requested / applied 模式、接受序号、active / init / release 掩码与每弦
started 序号；初始化完成不代表 DAC 或实物发声已经确认。旧位流禁用 KS，
DDS 仍可使用。Flash 音色库、Program Change 和 USB MIDI 未提供。

默认 DDS（32 声部）保持原音色与 bend。KS 使用独立四弦声部池，所有 MIDI
来源与页面 token 的同音高音符独立归属；CC64 延音、CC7 音量、CC10 声像
及 200–8000 ms 的 T60 衰减可调。KS 只在 NoteOn 调音，不做实时 bend。
切换模式会清除全部来源按键、延音及网页 held bitmap，并等待 FPGA applied
模式读回与 DDS 硬静音 bank 提交；完成后必须重新按键。KS 页面隐藏 DDS
参数但保留 `g_patch`，刷新页面只读取参数。

KS COMMIT 的接受与 MODE 应用确认有 50 ms 上限，初始化完成不使用这个
超时。SPI 读回失败、接受/模式序号或帧计数倒退会取消旧 On，发布
`EVT_PANIC` 清除全部来源及网页按键，并重建 DDS 静音双 bank；只有 owner
清键与 FPGA 安全 DDS 模式均确认后才恢复弹奏，旧 held 音符不会自动重放。
页面显示 `recovering`、`fault`（1=确认超时、2=读回失败、3=FPGA 复位）、
`recoveries` 和 `timeouts`，最后故障原因保留用于诊断。恢复仍依赖 FPGA
时钟及 SPI 返回有效；硬件持续故障时保持切换/恢复状态，不能声称已静音。

按键使用 250 ms 心跳和 1.2 秒租约；失焦、隐藏和卸载尝试发送松键，断网后
由 ESP32 自行释放该页面持有的声部。Release 尾音仍可能延续；点击“停止所有
声音”会关闭 bus 1023 的诊断测试音并立即 panic 所有来源的声部。最多同时
使用四个页面，各页面的按键 owner 独立，音色参数共享。

在 `idf.py menuconfig` 的 `FPGA local web control` 中可修改 SSID、WPA2 密码和
信道，或关闭 `CONFIG_ECT_WIFI_WEB`。演示密码适合首次本地试用；可换成
自己的 8–63 字符密码。留空会首次生成随机密码并保存 NVS，重启保持不变，
可在 USB 日志读取。固定密码会编译进固件，勿填写其他网络的私人凭据。
C3 原工程默认关闭 Wi-Fi，继续使用共享代码的原有 MIDI 功能。

Wi-Fi + NimBLE + 页面已超过原 1 MiB app 分区，因此 S3 默认改用 ESP-IDF 官方
`CONFIG_PARTITION_TABLE_SINGLE_APP_LARGE`（factory 1500 KiB）。部署时需要配套
新的分区表和应用，不能只用旧 1 MiB 分区刷应用。这里只构建，不进行烧录。
硬件验收仍需确认 `RESULT: ALL OK`，并检查手机多触点、BLE/Wi-Fi 同时使用、
拔网、紧急停止及实际音频延迟。
