#include "web_control.h"
#include <string.h>
#include <limits.h>
static portMUX_TYPE s_state_lock = portMUX_INITIALIZER_UNLOCKED;
static web_control_state_t s_state;
void web_control_store(const web_control_state_t *state)
{
    portENTER_CRITICAL(&s_state_lock);
    s_state = *state;
    portEXIT_CRITICAL(&s_state_lock);
}
void web_control_read(web_control_state_t *state)
{
    portENTER_CRITICAL(&s_state_lock);
    *state = s_state;
    portEXIT_CRITICAL(&s_state_lock);
}
bool web_control_cc_allowed(unsigned cc)
{
    switch (cc) {
    case 7: case 10: case 14: case 15: case 20: case 21: case 22: case 23:
    case 24: case 25: case 26: case 27: case 28: case 29: case 30: case 31:
    case 71: case 72: case 73: case 74: case 75: case 76: case 77: case 79:
    case 85: case 86: case 87: case 102: case 103: case 104: case 105:
    case 106: case 107: case 109: case 110: case 111: case 112: case 113:
        return true;
    default: return false;
    }
}
bool web_control_parse(const char *body, web_event_t *event)
{
    uint32_t n[5];
    const char *p = body;
    for (unsigned i = 0; i < 5; i++) {
        if (*p < '0' || *p > '9') return false;
        uint32_t v = 0;
        do {
            unsigned d = (unsigned)(*p++ - '0');
            if (v > (UINT32_MAX - d) / 10) return false;
            v = v * 10 + d;
        } while (*p >= '0' && *p <= '9');
        n[i] = v;
        if (i < 4) { if (*p++ != ' ') return false; }
    }
    if (*p || !n[0] || !n[1]) return false;
    if (n[2] == WEB_CC) {
        if (!web_control_cc_allowed(n[3]) || n[4] > 127) return false;
    } else if (n[2] == WEB_KEYS_UPDATE) {
        if (n[3] > WEB_KEYS_MASK || n[4] < 1 || n[4] > 127) return false;
    } else if (n[2] == WEB_STOP) {
        if (n[3] || n[4]) return false;
    } else if(n[2]==WEB_ENGINE) {
        if(n[3]>1 || n[4])return false;
    } else if(n[2]==WEB_KS_DECAY) {
        if(n[3]<200 || n[3]>8000 || n[4])return false;
    } else return false;
    *event = (web_event_t){.token=n[0], .sequence=n[1], .op=n[2], .a=n[3], .b=n[4]};
    return true;
}
