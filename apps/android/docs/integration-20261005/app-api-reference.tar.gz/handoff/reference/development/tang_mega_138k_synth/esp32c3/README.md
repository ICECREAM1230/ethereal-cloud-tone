# Tang Mega 138K synthesizer controller (legacy ESP32-C3 target)

This ESP-IDF application follows `open_resource` commit `4940a08`.
The shared `main/` sources now include conditional pin and ADC mapping for
`../esp32s3/`; the original C3 GPIO behavior remains available here.
The local CMake project name identifies the Tang Mega target.
The upstream license is preserved in `../LICENSE`.

It receives DIN MIDI on ESP32-C3 GPIO0, panel MIDI on GPIO2, and BLE MIDI;
allocates 32 voices of eight elements; maps the slider on GPIO1; and sends
32-bit parameter words, bus values, source table updates, and bank swaps to
the FPGA over SPI mode 0 at 10 MHz. The existing ESP32-C3 SPI pinout is:

| ESP32-C3 pin | Function | Tang Mega 138K JoyCon A / FPGA pin |
| --- | --- | --- |
| GPIO4 | SCLK | JoyCon A[0] / H19 |
| GPIO7 | CS, active low | JoyCon A[1] / H20 |
| GPIO6 | MOSI | JoyCon A[2] / G20 |
| GPIO5 | MISO | JoyCon A[3] / M17 |

These four FPGA pins come from `development/boards/tang_mega_138k/
tang_mega_138K_pins.cst`. Connect the boards' grounds and use 3.3 V I/O. The
ESP32-C3 must be restarted after FPGA configuration so it can rewrite its
full parameter image and silence the FPGA's boot sound, as in the original
Ethereal Cloud Tone bring-up flow.

From an ESP-IDF v6 shell, run `idf.py set-target esp32c3` once and then
`idf.py build`. Flashing the ESP32-C3 is a separate hardware step. The
FPGA bitstream is built from `../audio_i2s/eda_proj/`.

The 2026-10-01 ESP-IDF v6.1 check built this revision for `esp32c3` in
`/tmp/ect_fw_build/`. The generated firmware was not flashed. Hardware SPI
and audio operation still require testing on the connected boards. Build
directories and firmware binaries are not stored in Git.

The protocol source of truth is the current upstream `app/main/engine_link.c`,
`app/main/patch.c`, `rtl/spi/spi_bus.sv`, and `rtl/dsp/csp.sv`. Firmware and
FPGA gateware must be updated together: the instruction table now has four
words per entry, including two ADSR coefficient words. The adapted FPGA
modules are under `../audio_i2s/eda_proj/src/ect/`.
