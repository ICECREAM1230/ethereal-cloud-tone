// Desired images → bounded shadow commit → acknowledged live gates.
// Copyright © 2026 Thor H. Linløkken <thj@thj.no>
// License: MIT
#include "engine_link.h"
#include <string.h>
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "spi_regs.h"
#include "event_bus.h"

#define TAG "engine_link"
#define ENGINE_TASK_STACK 4096
#define ENGINE_TASK_PRIO 6
#define ENGINE_TICK_US 1000
#define ENGINE_BATCH_US 700
#define ELEM_BASE 0x2000
#define ELEM_STRIDE 64
#define PROD_BASE 0x0100
#define GATE_BASE 80
#define DIRTY_WORDS ((ENGINE_NUM_ELEMENTS * ENGINE_WORDS_PER_ELEMENT + 31) / 32)
#define PDIRTY_WORDS (ENGINE_NUM_PRODUCERS * 4 / 32)

// Producers only change desired state under the lock. The SPI owner takes a
// snapshot at a bank boundary; subsequent changes remain pending. There is
// no finite command queue to overflow during a full patch render.
static uint32_t s_desired[ENGINE_NUM_ELEMENTS][ENGINE_WORDS_PER_ELEMENT];
static uint32_t s_image[ENGINE_NUM_ELEMENTS][ENGINE_WORDS_PER_ELEMENT];
static uint32_t s_prod_desired[ENGINE_NUM_PRODUCERS][4];
static uint32_t s_prod[ENGINE_NUM_PRODUCERS][4];
static uint32_t s_prod_committed[ENGINE_NUM_PRODUCERS][4];
static uint32_t s_release_revision[ENGINE_NUM_PRODUCERS];
static uint32_t s_pending[DIRTY_WORDS], s_ppending[PDIRTY_WORDS];
static uint32_t s_dirty_now[DIRTY_WORDS], s_dirty_prev[DIRTY_WORDS];
static uint32_t s_pdirty_now[PDIRTY_WORDS], s_pdirty_prev[PDIRTY_WORDS];
static uint32_t s_bus[1024], s_bus_seq[1024], s_bus_done[1024], s_bus_dirty[32];
static struct {
    uint32_t seq, snapshot_seq;
    bool on, ready;
    uint8_t phase;             // 0 needs Off, 1 awaits completed pass
    uint16_t pass;
} s_notes[ENGINE_NUM_VOICES];
static portMUX_TYPE s_lock = portMUX_INITIALIZER_UNLOCKED;
static TaskHandle_t s_task;
static bool s_ready, s_flushing, s_swap_requested;
static unsigned s_elem_cursor, s_prod_cursor, s_live_cursor, s_gate_cursor, s_note_cursor;
static uint32_t s_drops;
static unsigned s_expected_bank;

static void mark(uint32_t *bits, unsigned bit) { bits[bit>>5] |= 1u << (bit&31); }
static void set_element(const engine_cmd_t *c)
{
    if (s_desired[c->elem][c->word] != c->value) {
        s_desired[c->elem][c->word] = c->value;
        mark(s_pending, c->elem * ENGINE_WORDS_PER_ELEMENT + c->word);
    }
}
static void set_prod(unsigned entry, unsigned word, uint32_t value)
{
    if (s_prod_desired[entry][word] != value) {
        s_prod_desired[entry][word] = value;
        mark(s_ppending, entry*4+word);
    }
}
bool engine_link_send(const engine_cmd_t *c)
{
    if (!s_ready || !c || c->word >= ENGINE_WORDS_PER_ELEMENT) return false;
    portENTER_CRITICAL(&s_lock); set_element(c); portEXIT_CRITICAL(&s_lock);
    return true;
}
bool engine_link_prod_write(uint8_t entry, uint8_t word, uint32_t value)
{
    if (!s_ready || word >= 4) return false;
    portENTER_CRITICAL(&s_lock); set_prod(entry, word, value); portEXIT_CRITICAL(&s_lock);
    return true;
}
bool engine_link_bus_write(uint16_t bus, uint32_t value)
{
    if (!s_ready || bus == 0 || bus >= 1024) return false;
    portENTER_CRITICAL(&s_lock);
    if (bus >= GATE_BASE && bus < GATE_BASE+ENGINE_NUM_VOICES) {
        // Gates must use the transaction interface for On. Off is always
        // accepted and invalidates a snapshot before it can re-gate.
        if (value != 0) { portEXIT_CRITICAL(&s_lock); s_drops++; return false; }
        unsigned v = bus-GATE_BASE;
        s_notes[v].on = false; s_notes[v].ready = false; s_notes[v].seq++;
        s_notes[v].phase = 0;
    }
    s_bus[bus] = value & 0x3FFFFu; s_bus_seq[bus]++; mark(s_bus_dirty,bus);
    portEXIT_CRITICAL(&s_lock);
    return true;
}
bool engine_link_note_on(const engine_note_t *n)
{
    if (!s_ready || !n || n->voice >= ENGINE_NUM_VOICES || n->count > ENGINE_NOTE_WORDS)
        return false;
    for (unsigned i=0; i<n->count; i++)
        if (n->words[i].word >= ENGINE_WORDS_PER_ELEMENT) return false;
    portENTER_CRITICAL(&s_lock);
    for (unsigned i=0; i<n->count; i++) set_element(&n->words[i]);
    set_prod(n->amp_entry, 2, n->amp_depth);
    set_prod(n->mod_entry, 2, n->mod_depth);
    unsigned cut=48+n->voice;
    s_bus[cut]=n->cutoff & 0x3FFFF; s_bus_seq[cut]++; mark(s_bus_dirty,cut);
    s_notes[n->voice].seq++; s_notes[n->voice].on=true;
    s_notes[n->voice].ready=false; s_notes[n->voice].phase=0;
    // Coalescing of the bank image is safe, but gate transitions are fenced:
    // every accepted replacement first exposes low to a complete CSP pass.
    unsigned gate=GATE_BASE+n->voice;
    s_bus[gate]=0; s_bus_seq[gate]++; mark(s_bus_dirty,gate);
    portEXIT_CRITICAL(&s_lock);
    return true;
}
uint32_t engine_link_drops(void) { return s_drops; }
uint32_t engine_link_prod_committed(uint8_t entry, uint8_t word)
{
    if (word>=4) return 0;
    portENTER_CRITICAL(&s_lock);
    uint32_t value=s_prod_committed[entry][word];
    portEXIT_CRITICAL(&s_lock);
    return value;
}
uint32_t engine_link_release_coefficient(uint8_t entry, uint32_t *revision)
{
    portENTER_CRITICAL(&s_lock);
    uint32_t k=(s_prod_committed[entry][3]>>4)&0x3FFFFu;
    *revision=s_release_revision[entry];
    portEXIT_CRITICAL(&s_lock);
    return k;
}
bool engine_link_bus_committed(uint16_t bus, uint32_t value)
{
    if (bus>=1024) return false;
    portENTER_CRITICAL(&s_lock);
    bool done=s_bus_seq[bus]==s_bus_done[bus] && s_bus[bus]==(value&0x3FFFFu);
    portEXIT_CRITICAL(&s_lock);
    return done;
}

static bool live_one(unsigned bus);

static void prepare_notes(int64_t deadline)
{
    for (unsigned n=0;n<ENGINE_NUM_VOICES && esp_timer_get_time()<deadline;n++) {
        unsigned v=s_note_cursor++ % ENGINE_NUM_VOICES;
        portENTER_CRITICAL(&s_lock);
        bool pending=s_notes[v].on && !s_notes[v].ready;
        uint32_t seq=s_notes[v].seq;
        unsigned phase=s_notes[v].phase;
        uint16_t pass=s_notes[v].pass;
        portEXIT_CRITICAL(&s_lock);
        if (!pending) continue;
        uint32_t status;
        if (phase==0) {
            if (!live_one(48+v) || !fpga_live_write(GATE_BASE+v,0) ||
                !fpga_control_status(&status)) break;
            portENTER_CRITICAL(&s_lock);
            if (s_notes[v].seq==seq) {
                s_notes[v].pass=status>>16; s_notes[v].phase=1;
                unsigned gate=GATE_BASE+v;
                s_bus_done[gate]=s_bus_seq[gate];
                s_bus_dirty[gate>>5] &= ~(1u<<(gate&31));
            }
            portEXIT_CRITICAL(&s_lock);
        } else {
            if (!fpga_control_status(&status)) break;
            // A pass in flight at Off ack may already have read old gate.
            // Two completions cover an entire subsequent pass, across wrap.
            if ((uint16_t)((status>>16)-pass)<2u) continue;
            portENTER_CRITICAL(&s_lock);
            if (s_notes[v].seq==seq) s_notes[v].ready=true;
            portEXIT_CRITICAL(&s_lock);
        }
    }
}
static bool live_one(unsigned bus)
{
    portENTER_CRITICAL(&s_lock);
    uint32_t seq=s_bus_seq[bus], done=s_bus_done[bus], value=s_bus[bus];
    portEXIT_CRITICAL(&s_lock);
    if (seq==done) return true;
    if (!fpga_live_write(bus,value)) return false;
    portENTER_CRITICAL(&s_lock);
    // A newer update during SPI remains pending; never mark it committed.
    s_bus_done[bus]=seq;
    if(s_bus_seq[bus]==seq) s_bus_dirty[bus>>5] &= ~(1u<<(bus&31));
    portEXIT_CRITICAL(&s_lock);
    return true;
}
static void begin_flush(void)
{
    portENTER_CRITICAL(&s_lock);
    memcpy(s_image,s_desired,sizeof(s_image)); memcpy(s_prod,s_prod_desired,sizeof(s_prod));
    memcpy(s_dirty_now,s_pending,sizeof(s_pending)); memset(s_pending,0,sizeof(s_pending));
    memcpy(s_pdirty_now,s_ppending,sizeof(s_ppending)); memset(s_ppending,0,sizeof(s_ppending));
    bool any=false;
    for (unsigned i=0;i<DIRTY_WORDS;i++) any |= (s_dirty_now[i]|s_dirty_prev[i]) != 0;
    for (unsigned i=0;i<PDIRTY_WORDS;i++) any |= (s_pdirty_now[i]|s_pdirty_prev[i]) != 0;
    for (unsigned v=0;v<ENGINE_NUM_VOICES;v++) {
        s_notes[v].snapshot_seq=s_notes[v].ready ? s_notes[v].seq : 0;
        any |= s_notes[v].snapshot_seq != 0;
    }
    s_flushing=any;
    portEXIT_CRITICAL(&s_lock);
    s_elem_cursor=0; s_prod_cursor=0; s_swap_requested=false;
}
static void finish_flush(void)
{
    // dirty_now UNION dirty_prev was written. After the confirmed swap, the
    // next shadow is one generation behind; retain only this batch's delta.
    memcpy(s_dirty_prev,s_dirty_now,sizeof(s_dirty_prev));
    memcpy(s_pdirty_prev,s_pdirty_now,sizeof(s_pdirty_prev));
    s_flushing=false;
    portENTER_CRITICAL(&s_lock);
    for(unsigned p=0;p<ENGINE_NUM_PRODUCERS;p++)
        if (((s_prod_committed[p][3]^s_prod[p][3]) & 0x3FFFF0u)!=0) s_release_revision[p]++;
    memcpy(s_prod_committed,s_prod,sizeof(s_prod_committed));
    portEXIT_CRITICAL(&s_lock);
    for (unsigned v=0;v<ENGINE_NUM_VOICES;v++) {
        portENTER_CRITICAL(&s_lock);
        bool on=s_notes[v].on && s_notes[v].ready &&
                s_notes[v].seq==s_notes[v].snapshot_seq;
        if (on) {
            unsigned gate=GATE_BASE+v;
            s_bus[gate]=1; s_bus_seq[gate]++; mark(s_bus_dirty,gate);
            // The desired bus entry will retry GateOn on any SPI failure.
            // A later Off supersedes it before the next live service.
            s_notes[v].ready=false; s_notes[v].on=false;
        }
        portEXIT_CRITICAL(&s_lock);
    }
}
// Return the next dirty non-gate bus, scanning words rather than all 1023
// addresses. Rotate after each dispatched address even if a producer keeps
// updating the first bus, so expression streams share the slice fairly.
static unsigned next_live_bus(void)
{
    portENTER_CRITICAL(&s_lock);
    for(unsigned n=0;n<33;n++) {
        unsigned start=(s_live_cursor+n*32)&1023u;
        unsigned word=start>>5;
        uint32_t bits=s_bus_dirty[word];
        if(word==0) bits &= ~1u;
        if(word==2) bits &= 0x0000FFFFu; // gate 80..95
        if(word==3) bits &= 0xFFFF0000u; // gate 96..111
        if(n==0) bits &= ~0u<<(s_live_cursor&31);
        else if(n==32) bits &= (1u<<(s_live_cursor&31))-1u;
        if(bits) {
            unsigned bus=word*32+__builtin_ctz(bits);
            s_live_cursor=(bus+1)&1023u;
            portEXIT_CRITICAL(&s_lock);
            return bus;
        }
    }
    portEXIT_CRITICAL(&s_lock);
    return 0;
}
#include "engine_ks.inc.h"
static void engine_service(void)
{
    int64_t deadline=esp_timer_get_time()+ENGINE_BATCH_US;
    ks_service();
    // Dedicated slices keep release, note preparation, expression and shadow
    // work making progress under continuous traffic in any one category.
    int64_t gate_deadline=esp_timer_get_time()+200;
    for (unsigned n=0;n<ENGINE_NUM_VOICES && esp_timer_get_time()<gate_deadline;n++) {
        unsigned bus=GATE_BASE+s_gate_cursor++%ENGINE_NUM_VOICES;
        if (!live_one(bus)) break;
    }
    int64_t note_deadline=esp_timer_get_time()+150;
    if(note_deadline>deadline) note_deadline=deadline;
    prepare_notes(note_deadline);
    int64_t live_deadline=esp_timer_get_time()+100;
    if(live_deadline>deadline) live_deadline=deadline;
    while(esp_timer_get_time()<live_deadline) {
        unsigned bus=next_live_bus();
        if(!bus || !live_one(bus)) break;
    }
    // A reset/lost acknowledgement abandons the old bank transaction. Wait
    // for its hardware pending flag before rebuilding both muted images.
    if(!ks_bank_ready())return;
    if (!s_flushing) {
        if (esp_timer_get_time()>=deadline) return;
        // Pending gates that have not yet observed low are excluded from the
        // On snapshot; they cannot block prepared notes or ordinary updates.
        begin_flush();
    }
    if (!s_flushing) return;
    while (s_elem_cursor<ENGINE_NUM_ELEMENTS && esp_timer_get_time()<deadline) {
        unsigned e=s_elem_cursor++; bool dirty=false;
        for(unsigned w=0;w<ENGINE_WORDS_PER_ELEMENT;w++) {
            unsigned bit=e*ENGINE_WORDS_PER_ELEMENT+w;
            dirty |= ((s_dirty_now[bit>>5]|s_dirty_prev[bit>>5]) & (1u<<(bit&31)))!=0;
        }
        if(dirty) fpga_word_write_burst(ELEM_BASE+e*ELEM_STRIDE,s_image[e],ENGINE_WORDS_PER_ELEMENT);
    }
    while(s_elem_cursor==ENGINE_NUM_ELEMENTS && s_prod_cursor<ENGINE_NUM_PRODUCERS*4 &&
          esp_timer_get_time()<deadline) {
        unsigned bit=s_prod_cursor++;
        if((s_pdirty_now[bit>>5]|s_pdirty_prev[bit>>5]) & (1u<<(bit&31)))
            fpga_word_write(PROD_BASE+bit,s_prod[bit/4][bit%4]);
    }
    if(s_prod_cursor<ENGINE_NUM_PRODUCERS*4 || esp_timer_get_time()>=deadline) return;
    uint32_t status;
    if (!fpga_control_status(&status)) return;
    if (!s_swap_requested) {
        if(status&2u) return; // another request must complete before reuse
        s_expected_bank=(status&1u)^1u;
        fpga_word_write(0x0002,1);
        s_swap_requested=true;
        return;
    }
    if (!(status&2u) && (status&1u)==s_expected_bank) finish_flush();
}
static void tick_cb(void *arg) { (void)arg; xTaskNotifyGive(s_task); }
static void engine_task(void *arg)
{
    (void)arg;
    while(1) {
        ulTaskNotifyTake(pdTRUE,portMAX_DELAY);
        engine_service();
        // Drop accumulated periodic notifications, then block until a future
        // timer wake. Each service is bounded in µs, never rounded to a 10 ms
        // vTaskDelay(1), and cannot monopolize the single-core idle task.
        ulTaskNotifyTake(pdTRUE,0);
    }
}
void engine_link_init(void)
{
    memset(s_desired,0,sizeof(s_desired));
    for(unsigned e=0;e<ENGINE_NUM_ELEMENTS;e++) s_desired[e][2]=0x40000000;
    memcpy(s_image,s_desired,sizeof(s_image));
    for(unsigned bank=0;bank<2;bank++) {
        for(unsigned e=0;e<ENGINE_NUM_ELEMENTS;e++)
            fpga_word_write_burst(ELEM_BASE+e*ELEM_STRIDE,s_image[e],ENGINE_WORDS_PER_ELEMENT);
        if (!fpga_swap_checked()) {
            ESP_LOGE(TAG,"boot bank swap was not acknowledged; engine unavailable");
            return;
        }
    }
    s_ready=true;
    ks_probe();
    if(xTaskCreate(engine_task,"engine_link",ENGINE_TASK_STACK,NULL,ENGINE_TASK_PRIO,&s_task)!=pdPASS) {
        s_ready=false; ESP_LOGE(TAG,"failed to create task"); return;
    }
    const esp_timer_create_args_t args={.callback=tick_cb,.name="engine_tick"};
    esp_timer_handle_t timer;
    ESP_ERROR_CHECK(esp_timer_create(&args,&timer));
    ESP_ERROR_CHECK(esp_timer_start_periodic(timer,ENGINE_TICK_US));
    ESP_LOGI(TAG,"bounded 1 kHz control service running");
}
