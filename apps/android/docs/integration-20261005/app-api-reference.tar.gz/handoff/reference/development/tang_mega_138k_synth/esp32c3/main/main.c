// Copyright © 2026 Thor H. Linløkken <thj@thj.no>
// License: MIT

#include <stdio.h>
#include <inttypes.h>
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_chip_info.h"
#include "esp_flash.h"
#include "esp_system.h"
#include "esp_app_desc.h"

#include "spi_regs.h"
#include "midi_in.h"
#include "midi_log.h"
#include "event_bus.h"
#include "engine_link.h"
#include "voice_alloc.h"
#include "slider.h"
#include "ble_midi.h"
#include "stress_test.h"
#include "wifi_web.h"
#if defined(CONFIG_IDF_TARGET_ESP32S3)
#include "driver/gpio.h"
#endif

#if defined(CONFIG_IDF_TARGET_ESP32S3)
#define DIN_MIDI_RX_PIN 16  // GPIO0 is the BOOT key on the YD-ESP32-S3 board.
// Fixed seven-wire board: FPGA E19/C18/E14 must be passive, no-pull inputs.
// GPIO19/20 remain native USB and GPIO0 remains BOOT; never drive them here.
// GPIO45 is MOSI so the FPGA input cannot drive this strapping pin at reset.
// GPIO48 also feeds the board's RGB LED input; do not enable an LED driver.
#define FPGA_SPI_MOSI_PIN 45  // C15
#define FPGA_SPI_MISO_PIN 48  // B13
#define FPGA_SPI_SCLK_PIN 47  // A14
#define FPGA_SPI_CS_PIN   21  // B16
#else
#define DIN_MIDI_RX_PIN 0
#define FPGA_SPI_MOSI_PIN 6
#define FPGA_SPI_MISO_PIN 5
#define FPGA_SPI_SCLK_PIN 4
#define FPGA_SPI_CS_PIN   7
#endif

void app_main(void)
{
    // Boot banner: WHICH build is running (esp_app_desc is regenerated
    // every build — version is git-describe, date/time is the compile).
    // Exists because a hash-verified flash once left the old app running
    // (USB-JTAG hard-reset quirk): trust this line, not esptool's exit.
    const esp_app_desc_t *ad = esp_app_get_description();
    printf("=== ect fw %s (built %s %s) ===\n",
           ad->version, ad->date, ad->time);

    /* Print chip information */
    esp_chip_info_t chip_info;
    uint32_t flash_size;
    esp_chip_info(&chip_info);
    printf("This is %s chip with %d CPU core(s), %s%s%s%s, ",
           CONFIG_IDF_TARGET,
           chip_info.cores,
           (chip_info.features & CHIP_FEATURE_WIFI_BGN) ? "WiFi/" : "",
           (chip_info.features & CHIP_FEATURE_BT) ? "BT" : "",
           (chip_info.features & CHIP_FEATURE_BLE) ? "BLE" : "",
           (chip_info.features & CHIP_FEATURE_IEEE802154) ? ", 802.15.4 (Zigbee/Thread)" : "");

    unsigned major_rev = chip_info.revision / 100;
    unsigned minor_rev = chip_info.revision % 100;
    printf("silicon revision v%d.%d, ", major_rev, minor_rev);
    if(esp_flash_get_size(NULL, &flash_size) != ESP_OK) {
        printf("Get flash size failed");
        return;
    }

    printf("%" PRIu32 "MB %s flash\n", flash_size / (uint32_t)(1024 * 1024),
           (chip_info.features & CHIP_FEATURE_EMB_FLASH) ? "embedded" : "external");

    printf("Minimum free heap size: %" PRIu32 " bytes\n", esp_get_minimum_free_heap_size());

    // Event bus first, then the consumers that subscribe to it.
    event_bus_init();
    midi_log_init();

    // Initialize UART pin routing before the SPI bus claims its pins.
    midi_in_init(DIN_MIDI_RX_PIN);

    // Panel MIDI (#90): UART0 on GPIO2, from an external MIDI input.
    // Open Stage Control exclusively — test scripts stay on BLE/DIN.
    midi_panel_init(2);

    // Keep 10 MHz for the engine's 1 ms tick; validate the new wiring
    // with the word-protocol self-test below before testing MIDI.
    fpga_spi_init(FPGA_SPI_MOSI_PIN, FPGA_SPI_MISO_PIN,
                  FPGA_SPI_SCLK_PIN, FPGA_SPI_CS_PIN, 10000000);

#if defined(CONFIG_IDF_TARGET_ESP32S3)
    // IDF may route SPIQ output as well as input to MISO for dual-I/O support.
    // This board uses single-line full-duplex SPI with FPGA-driven MISO only.
    // Force pad OE off while retaining the SPIQ input matrix connection.
    ESP_ERROR_CHECK(gpio_output_disable(FPGA_SPI_MISO_PIN));
    ESP_ERROR_CHECK(gpio_input_enable(FPGA_SPI_MISO_PIN));
    ESP_ERROR_CHECK(gpio_set_pull_mode(FPGA_SPI_MISO_PIN, GPIO_FLOATING));
    printf("=== fixed seven-wire GPIO safety: USB/BOOT preserved, MISO input only ===\n");
    ESP_ERROR_CHECK(gpio_dump_io_configuration(stdout,
        (1ULL << 0) | (1ULL << 19) | (1ULL << 20) | (1ULL << 21) |
        (1ULL << 45) | (1ULL << 47) | (1ULL << 48)));
#endif

    // Word-protocol self-test (spi_bus.sv / docs/memory_map.md format).
    // Mirrors tb_spi_bus.sv's cases so firmware and RTL agree on the
    // same evidence.
    int fails = 0;

    printf("=== 1. single word write/read ===\n");
    fpga_word_write(0x0005, 0xDEADBEEF);
    uint32_t v = fpga_word_read(0x0005);
    printf("word[0x0005] = %08lX %s\n", (unsigned long)v,
           v == 0xDEADBEEF ? "OK" : "FAIL");
    fails += (v != 0xDEADBEEF);

    printf("=== 2. burst auto-increment (LFO region) ===\n");
    uint32_t wq[4] = {0x11111111, 0x22222222, 0x33333333, 0x44444444};
    uint32_t rq[4] = {0};
    fpga_word_write_burst(0x0100, wq, 4);
    bool id_ok = fpga_word_read_burst(0x0100, rq, 4);
    for (int i = 0; i < 4; i++) {
        printf("word[0x%04X] = %08lX %s\n", 0x0100 + i, (unsigned long)rq[i],
               rq[i] == wq[i] ? "OK" : "FAIL");
        fails += (rq[i] != wq[i]);
    }
    printf("ID byte on read frame: %s\n", id_ok ? "OK (A5)" : "FAIL");
    fails += !id_ok;

    printf("=== 3. out-of-window: dropped and zero, no alias ===\n");
    // 0x1005 aliases 0x0005 under the 11-bit backed mask AND decodes
    // to nothing else. The previous probe address, 0x0805, was inside
    // the BUS POOL (0x0800-0x0BFF): the store dropped it as intended,
    // but spi_bus fired the bus mailbox and parked bus 5 at a large
    // negative base every boot - a self-test moving a live fader
    // (issue #103). Probe addresses must miss EVERY decode window:
    // backed 0x0000-0x07FF, bus 0x0800-0x0BFF, elements 0x2000-0x5FFF.
    fpga_word_write(0x1005, 0xBAD0BAD0);      // would alias 0x0005 if broken
    uint32_t z = fpga_word_read(0x1005);
    uint32_t keep = fpga_word_read(0x0005);
    printf("word[0x1005] = %08lX %s, word[0x0005] = %08lX %s\n",
           (unsigned long)z, z == 0 ? "OK" : "FAIL",
           (unsigned long)keep, keep == 0xDEADBEEF ? "OK" : "FAIL");
    fails += (z != 0) + (keep != 0xDEADBEEF);

    printf("=== RESULT: %s (%d fails) ===\n", fails ? "FAIL" : "ALL OK", fails);

    // ── The synth proper ────────────────────────────────────────────
    // engine_link takes sole ownership of the SPI link from here on
    // (mutes both banks at init — the boot organ goes silent), then
    // voice_alloc turns MIDI into voices of 8 elements.
    printf("=== voice concept: 32 voices x 8 elements, MIDI omni ===\n");
    engine_link_init();
    voice_alloc_init();
    slider_init();   // panel slider -> CC71 (resonance); 'c' = calibrate
    ble_midi_init(); // MIDI over BLE: advertise "FPGA_Bluetooth" (standard MIDI service)
    wifi_web_start(); // optional local SoftAP, below musical task priorities
#if CONFIG_ECT_STRESS_TEST
    stress_test_start();  // synthetic MIDI flood (#70 repro); off by default
#endif
    // NOTE: boot-capture tooling waits for the "play the keyboard"
    // marker - keep the prefix if this line ever changes.
    printf("play the keyboard\n");   // (the gate-by-gain/clicks caveat
                                     // predates the ADSR era - #110)
}
