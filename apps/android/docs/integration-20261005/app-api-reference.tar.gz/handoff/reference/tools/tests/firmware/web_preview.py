#!/usr/bin/env python3
"""Local browser fixture only: never accesses ESP32/FPGA or reports hardware proof."""
import argparse
import copy
import json
import re
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
PAGE = Path(__file__).resolve().parents[3] / "development/tang_mega_138k_synth/esp32c3/main/web/index.html"
STATE = {"ready": True, "revision": 1, "panic": 0, "rendering": False,
         "test_tone": False, "fpga": "unverified", "tokens": [0]*4,
         "processed": [0]*4, "parameter_processed": [0]*4, "stop_processed": [0]*4,
         "keys": [0]*4, "osc": [[0, 0, 0, 0], [3, -12, 0, 0]], "voice": 1,
         "mix": 0, "detune": 6, "spread": 127, "volume": 207, "pan": 0,
         "filter": [0, 512, 0, 1, 64], "cutoff_offset": 0, "resonance_offset": 0,
         "amp": [152, 32, 240, 40], "mod": [152, 32, 240, 40], "mod_depth": 2048,
         "lfo": [[2, 350, 16, 0], [2, 350, 0, 0]], "velocity": [64, 64],
         "fixture": "NO HARDWARE: simulated HTTP state, never SPI or audio proof",
         "ks_decay_ms": 3000,
         "engine": {"available": False, "valid": False, "requested": 0, "applied": 0,
                    "switching": False, "busy": False, "recovering": False,
                    "fault": 0, "recoveries": 0, "timeouts": 0, "active": 0,
                    "init": 0, "release": 0, "accepted": 0, "mode_sequence": 0,
                    "rejects": 0, "frames": 0, "deadlines": 0, "started": [0]*4}}
class Handler(BaseHTTPRequestHandler):
    state = copy.deepcopy(STATE)
    seen = [0.0]*4
    armed = [False]*4
    mode_due = recovery_due = 0.0
    capable = False
    @classmethod
    def configure(cls, capable=False, recovering=False, recovery_delay=2.0):
        cls.capable = capable
        cls.state = copy.deepcopy(STATE)
        cls.seen = [0.0]*4
        cls.armed = [False]*4
        cls.mode_due = 0.0
        cls.recovery_due = time.monotonic()+recovery_delay if recovering else 0.0
        cls.state["engine"].update(available=capable, valid=capable and not recovering,
                                   recovering=recovering, switching=recovering,
                                   fault=2 if recovering else 0,
                                   recoveries=1 if recovering else 0)
    @classmethod
    def record(cls, event, **fields):
        print(json.dumps({"fixture": "NO HARDWARE", "at": time.monotonic(),
                          "event": event, **fields}, ensure_ascii=False), flush=True)
    @classmethod
    def clear_keys(cls):
        cls.state["keys"] = [0]*4
        cls.armed = [False]*4
        cls.state["engine"]["active"] = 0
    @classmethod
    def advance(cls):
        now = time.monotonic()
        e = cls.state["engine"]
        if cls.recovery_due and now >= cls.recovery_due:
            cls.recovery_due = 0.0
            cls.clear_keys()
            e.update(available=cls.capable, valid=cls.capable, requested=0, applied=0,
                     recovering=False, switching=False, busy=False)
            cls.state["panic"] += 1
            cls.state["revision"] += 1
            cls.record("recovered-safe-dds", keys=cls.state["keys"], engine=e)
        if cls.mode_due and now >= cls.mode_due:
            cls.mode_due = 0.0
            e.update(applied=e["requested"], switching=False, busy=False,
                     mode_sequence=e["accepted"])
            cls.state["revision"] += 1
            cls.record("mode-applied", keys=cls.state["keys"], engine=e)
        for i, keys in enumerate(cls.state["keys"]):
            if keys and now-cls.seen[i] >= 1.2:
                cls.state["keys"][i] = 0
                cls.armed[i] = False
                cls.state["revision"] += 1
                cls.record("lease-expired", client=i)
        e["active"] = int(any(cls.state["keys"])) if e["applied"] else 0
    def log_message(self, fmt, *args):
        pass
    def respond(self, status, payload, kind="application/json"):
        data = payload.encode() if isinstance(payload, str) else json.dumps(payload).encode()
        self.send_response(status); self.send_header("Content-Type", kind)
        self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        self.advance()
        if self.path == "/":
            # Mark the served preview; the production page on disk remains unchanged.
            page = PAGE.read_text().replace("<main>", '<main><p role="note" style="color:#ffc084;border:1px solid #ffc084;padding:12px">本地 UI fixture · NO HARDWARE · HTTP 状态为模拟，未访问 ESP32 / FPGA / 音频。</p>', 1)
            self.respond(200, page, "text/html; charset=utf-8")
        elif self.path == "/api/state": self.respond(200, self.state)
        else: self.respond(404, {})
    def do_POST(self):
        self.advance()
        body = self.rfile.read(int(self.headers.get("Content-Length", 0))).decode()
        if self.path == "/api/session":
            now = time.monotonic()
            free = [i for i in range(4) if not self.state["tokens"][i] or now-self.seen[i]>=10]
            if not free: self.respond(503, {}); return
            i = free[0]; self.seen[i] = now
            token = ((int(now*1000)*4+i) & 0xffffffff) or i+1
            self.state["tokens"][i] = token
            self.state["keys"][i] = 0; self.armed[i] = False
            for field in ("processed", "parameter_processed", "stop_processed"):
                self.state[field][i] = 0
            self.record("session", client=i, token=token)
            self.respond(201, {"token": token, "client": i, "lease_ms": 1200}); return
        if self.path != "/api/command": self.respond(404, {}); return
        try:
            if not re.fullmatch(r"[0-9]+(?: [0-9]+){4}", body): raise ValueError()
            token, sequence, op, a, b = map(int, body.split())
            if not token or not sequence or max(token, sequence) > 0xffffffff: raise ValueError()
            i = self.state["tokens"].index(token)
        except (ValueError, TypeError): self.respond(400, {}); return
        if sequence <= self.state["processed"][i]: self.respond(409, {}); return
        if not ((op == 2 and a <= 127 and b <= 127) or
                (op == 3 and a < (1 << 25) and 1 <= b <= 127) or
                (op == 4 and a == b == 0) or (op == 5 and a <= 1 and b == 0) or
                (op == 6 and 200 <= a <= 8000 and b == 0)):
            self.respond(400, {}); return
        e = self.state["engine"]
        if op == 5 and (e["recovering"] or e["switching"] or a and not e["available"]):
            self.respond(409, {}); return
        if op == 6 and not e["available"]: self.respond(409, {}); return
        self.seen[i] = time.monotonic()
        self.state["processed"][i] = sequence
        if op == 2:
            self.state["parameter_processed"][i] = sequence
            if a == 7: self.state["volume"] = b*2
            elif a in (20,21): self.state["osc"][a-20][0] = b>>5
            elif a == 10: self.state["pan"] = b-64
        elif op == 3:
            if not a: self.armed[i] = True
            self.state["keys"][i] = a if self.armed[i] and not e["switching"] else 0
        elif op == 4:
            self.state["panic"] += 1; self.clear_keys()
            self.state["stop_processed"][i] = sequence
        elif op == 5:
            self.clear_keys(); self.state["panic"] += 1
            self.state["parameter_processed"][i] = sequence
            e.update(requested=a, switching=True, busy=True, accepted=e["accepted"]+1)
            type(self).mode_due = time.monotonic()+0.08
        elif op == 6:
            self.state["ks_decay_ms"] = a
            self.state["parameter_processed"][i] = sequence
        self.state["revision"] += 1
        self.record("command", client=i, sequence=sequence, op=op, a=a, b=b,
                    keys=self.state["keys"], engine=e)
        self.respond(202, {"accepted": sequence, "stage": "received", "fpga": "unverified"})
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--ks-capable", action="store_true", help="simulate KS01 capability; default DDS")
    parser.add_argument("--recovering", action="store_true", help="simulate readback failure followed by safe DDS recovery")
    parser.add_argument("--recovery-delay", type=float, default=2.0, help="seconds before simulated recovery (default: 2)")
    args = parser.parse_args()
    if args.recovery_delay < 0: parser.error("--recovery-delay must be nonnegative")
    Handler.configure(args.ks_capable, args.recovering, args.recovery_delay)
    print(f"Browser fixture (no hardware): http://127.0.0.1:{args.port}", flush=True)
    HTTPServer(("127.0.0.1", args.port), Handler).serve_forever()
