#!/bin/bash
set -euo pipefail
repo=$(cd "$(dirname "$0")/../../.." && pwd)
cd "$repo"
fw=development/tang_mega_138k_synth/esp32c3/main
out=$(mktemp -d /tmp/firmware-host.XXXXXX)
trap 'rm -rf "$out"' EXIT
cc -std=c11 -Wall -Wextra -Werror -DRELIABLE_EVENTS -Itools/tests/firmware/stubs -I"$fw" \
    tools/tests/firmware/fake_queue.c tools/tests/firmware/test_event_bus.c "$fw/event_bus.c" -o "$out/event_bus"
"$out/event_bus"
cc -std=c11 -Wall -Wextra -Werror -Wno-misleading-indentation -DTRANSACTION_ENGINE -Itools/tests/firmware/stubs -I"$fw" \
    tools/tests/firmware/fake_queue.c tools/tests/firmware/fake_runtime.c tools/tests/firmware/test_engine_order.c "$fw/event_bus.c" -o "$out/engine"
"$out/engine"
cc -std=c11 -Wall -Wextra -Werror -Itools/tests/firmware/stubs -I"$fw" \
    tools/tests/firmware/fake_queue.c tools/tests/firmware/fake_runtime.c tools/tests/firmware/test_voice_deadline.c "$fw/event_bus.c" "$fw/patch.c" "$fw/web_control.c" "$fw/ks_params.c" "$fw/ks_voice.c" tools/tests/firmware/fake_ks_engine.c -lm -o "$out/voice_deadline"
"$out/voice_deadline"
cc -std=c11 -Wall -Wextra -Werror -DRC_RELEASE -Itools/tests/firmware/stubs -I"$fw" \
    tools/tests/firmware/fake_queue.c tools/tests/firmware/fake_runtime.c tools/tests/firmware/test_release_model.c "$fw/event_bus.c" "$fw/patch.c" "$fw/web_control.c" "$fw/ks_params.c" "$fw/ks_voice.c" tools/tests/firmware/fake_ks_engine.c -lm -o "$out/release"
"$out/release"
cc -std=c11 -Wall -Wextra -Werror -Itools/tests/firmware/stubs -I"$fw" \
    tools/tests/firmware/fake_runtime.c tools/tests/firmware/test_spi_fences.c "$fw/spi_regs.c" -o "$out/spi_fences"
"$out/spi_fences"
cc -std=c11 -Wall -Wextra -Werror -Itools/tests/firmware/stubs -I"$fw" \
    tools/tests/firmware/test_midi_source.c -o "$out/midi_source"
"$out/midi_source"
cc -std=c11 -Wall -Wextra -Werror -Itools/tests/firmware/stubs -I"$fw" \
    tools/tests/firmware/fake_queue.c tools/tests/firmware/fake_runtime.c tools/tests/firmware/test_web_control.c "$fw/event_bus.c" "$fw/patch.c" "$fw/web_control.c" "$fw/ks_params.c" "$fw/ks_voice.c" tools/tests/firmware/fake_ks_engine.c -lm -o "$out/web_control"
"$out/web_control"
cc -std=c11 -Wall -Wextra -Werror -Itools/tests/firmware/stubs -I"$fw" \
    tools/tests/firmware/fake_queue.c tools/tests/firmware/fake_runtime.c tools/tests/firmware/test_ks_engine.c "$fw/event_bus.c" -o "$out/ks_engine"
"$out/ks_engine"
cc -std=c11 -Wall -Wextra -Werror -Itools/tests/firmware/stubs -I"$fw" \
    tools/tests/firmware/test_ks_voice.c "$fw/ks_params.c" "$fw/patch.c" -lm -o "$out/ks_voice"
"$out/ks_voice"
cc -std=c11 -Wall -Wextra -Werror -Itools/tests/firmware/stubs -I"$fw" \
    tools/tests/firmware/fake_queue.c tools/tests/firmware/fake_runtime.c tools/tests/firmware/test_ks_web.c \
    "$fw/event_bus.c" "$fw/patch.c" "$fw/web_control.c" "$fw/ks_params.c" "$fw/ks_voice.c" -lm -o "$out/ks_web"
"$out/ks_web"
cc -std=c11 -Wall -Wextra -Werror -I"$fw" \
    tools/tests/firmware/ks_parameter_dump.c "$fw/ks_params.c" -lm -o "$out/ks_parameters"
"$out/ks_parameters" > "$out/ks_parameters.csv"
python3 - "$out/ks_parameters.csv" <<'PY'
import csv, sys
with open('tools/tests/firmware/ks_parameters_expected.csv') as f:
    expected = list(csv.reader(f))[1:]
with open(sys.argv[1]) as f:
    actual = [row[:4] for row in csv.reader(f)]
assert len(actual) == 128 and actual == expected, 'L/C/rho diverged from independent 128-note golden'
print('KS parameters: all 128 MIDI L/C/rho exactly match independent golden PASS')
PY
node tools/tests/firmware/test_web_page.js
