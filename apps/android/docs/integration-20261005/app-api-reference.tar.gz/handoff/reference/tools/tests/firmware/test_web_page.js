// Runs the real page script in a minimal DOM; no browser or external packages.
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
class Element{
 constructor(tag='div'){this.tag=tag;this.children=[];this.events={};this.dataset={};this.value='';this.className='';this.classList={toggle(){},add(){},remove(){}};}
 append(...nodes){this.children.push(...nodes)}
 addEventListener(kind,fn){this.events[kind]=fn}
 setAttribute(){} setPointerCapture(){}
}
const nodes=new Map();for(const name of ['osc','mix','filter','amp','tune1','tune2','lfo','keyboard','velocity','stop','connection','feedback','raw','testWarning','engine','ksOption','engineStatus','ksControls','decay','decayValue'])nodes.set(name,new Element());nodes.get('velocity').value='100';
const page=fs.readFileSync('development/tang_mega_138k_synth/esp32c3/main/web/index.html','utf8'),script=page.match(/<script>([\s\S]*?)<\/script>/)[1];
const state={ready:true,revision:1,panic:0,rendering:false,test_tone:false,tokens:[123,0,0,0],processed:[0,0,0,0],parameter_processed:[0,0,0,0],stop_processed:[0,0,0,0],keys:[0,0,0,0],osc:[[0,0,0,0],[3,-12,0,0]],voice:1,mix:0,detune:6,spread:127,volume:207,pan:0,engine:{available:false,valid:false,requested:0,applied:0,switching:false,active:0,init:0,accepted:0},ks_decay_ms:3000,filter:[0,512,0,1,64],cutoff_offset:0,resonance_offset:0,amp:[152,32,240,40],lfo:[[2,350,16,0],[2,350,0,0]]};
let clock=0,hold=null,delay=false,adopt=true;const commands=[],intervals=[],timers=[];
const document={hidden:false,getElementById:id=>nodes.get(id),createElement:tag=>new Element(tag),createTextNode:text=>({text}),querySelectorAll:selector=>selector==='.key'?nodes.get('keyboard').children:[],addEventListener(){}};
const context=vm.createContext({document,window:{addEventListener(){}},AbortController,performance:{now:()=>clock},queueMicrotask,setInterval:fn=>intervals.push(fn),setTimeout:fn=>{timers.push(fn);return fn},clearTimeout:fn=>{const i=timers.indexOf(fn);if(i>=0)timers.splice(i,1)},fetch:async(url,options)=>{
 if(url==='/api/session')return{ok:true,json:async()=>({token:123,client:0})};
 if(url==='/api/state')return{ok:true,json:async()=>structuredClone(state)};
 const fields=options.body.split(' ').map(Number);commands.push(fields);
 if(fields[2]===5){state.parameter_processed[0]=fields[1];state.engine.requested=state.engine.applied=fields[3];state.panic++;state.keys[0]=0;}
 if(fields[2]===6){state.parameter_processed[0]=fields[1];state.ks_decay_ms=fields[3];}
 if(fields[2]===3&&adopt){state.processed[0]=fields[1];state.keys[0]=fields[3]}
 if(delay){delay=false;await new Promise(resolve=>hold=resolve)}
 return{ok:true,json:async()=>({accepted:fields[1]})};
},console});
vm.runInContext(script,context);
const flush=async()=>{for(let i=0;i<15;i++)await new Promise(resolve=>setImmediate(resolve))};
const keys=nodes.get('keyboard').children,down=(k,id)=>keys[k].events.pointerdown({pointerId:id,preventDefault(){}}),up=(k,id)=>keys[k].events.pointerup({pointerId:id});
(async()=>{
 await flush();nodes.get('velocity').value='100.5';assert.equal(context.velocity(),101,'fractional velocity must normalize to integer');nodes.get('velocity').value='100';assert.equal(commands.length,0,'loading must not submit defaults');
 await context.pump();await flush();assert.equal(commands.at(-1)[3],0);
 delay=true;down(12,1);up(12,1); // Short tap while the On HTTP request is busy.
 await flush();assert.equal(commands.at(-1)[3],1<<12);hold();await flush();
 assert.deepEqual(commands.slice(-2).map(c=>c[3]),[1<<12,0],'short On/Off must survive busy HTTP');
 down(12,2);await flush();down(12,3);up(12,2);await flush();assert.equal(state.keys[0],1<<12,'second pointer keeps same key held');up(12,3);await flush();assert.equal(state.keys[0],0);
 // HTTP202 is insufficient: no Off until owner keys reflect the preceding On.
 adopt=false;down(4,4);up(4,4);await flush();const count=commands.length;assert.equal(commands.at(-1)[3],1<<4);
 assert.equal(commands.length,count);state.keys[0]=1<<4;state.processed[0]=commands.at(-1)[1];adopt=true;
 const wake=timers.pop();wake();await flush();assert.equal(commands.at(-1)[3],0,'Off follows owner adoption');
 // A late queued On must be discarded, followed by release rather than revival.
 delay=true;down(1,5);await flush();down(2,6);clock=400;hold();await flush();assert.equal(commands.at(-1)[3],0);assert.equal(state.keys[0],0);
 assert(commands.every(c=>c[2]!==2),'keyboard tests must not submit CC defaults');
 // Capability controls the option, loading/polling never writes parameters.
 assert.equal(nodes.get('ksOption').disabled,true);const loaded=commands.length;await context.poll();assert.equal(commands.length,loaded);
 state.engine.available=state.engine.valid=true;await context.poll();assert.equal(nodes.get('ksOption').disabled,false);
 // A queued held key is cleared before mode submission; apply readback is explicit.
 down(3,7);await flush();nodes.get('engine').value='1';nodes.get('engine').events.change();await flush();
 assert(commands.some(c=>c[2]===5&&c[3]===1));assert.equal(state.keys[0],0);assert.equal(context.mask(),0);assert.equal(nodes.get('ksControls').hidden,false);
 assert(nodes.get('engineStatus').textContent.includes('FPGA KS'));assert.equal(nodes.get('osc').children[0].hidden,true);assert.equal(nodes.get('mix').children[0].hidden,false);
 nodes.get('decay').value='200.4';nodes.get('decay').events.input();await context.pump();await flush();assert.equal(state.ks_decay_ms,200);
 nodes.get('engine').value='0';nodes.get('engine').events.change();await flush();assert.equal(nodes.get('ksControls').hidden,true);assert.equal(nodes.get('osc').children[0].hidden,false);
 assert(commands.every(c=>c[2]!==2),'mode switch must preserve DDS parameter snapshot');
 state.engine.recovering=state.engine.switching=true;state.engine.available=false;state.engine.fault=2;state.panic++;await context.poll();
 assert.equal(keys[0].disabled,true);assert(nodes.get('engineStatus').textContent.includes('弹奏暂停'));assert.equal(context.mask(),0);
 state.engine.recovering=state.engine.switching=false;state.engine.available=true;await context.poll();assert.equal(keys[0].disabled,false);
 assert(nodes.get('engineStatus').textContent.includes('故障 2'),'sticky diagnostics survive safe DDS recovery');
 console.log('web page: no default writes, busy short tap, same-key pointers, owner adoption fence, stale-On release, integer velocity, capability, mode clear/readback, DDS preservation, decay bounds, recovery pause/diagnostics PASS');
})().catch(e=>{console.error(e);process.exitCode=1});
